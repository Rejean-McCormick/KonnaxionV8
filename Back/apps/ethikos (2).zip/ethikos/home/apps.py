from django.apps import AppConfig

class EthikosHomeConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'ethikos.home'
    verbose_name = "Ethikos Home"
