from django.apps import AppConfig

class EthikosDebateArenaConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'ethikos.debate_arena'
    verbose_name = "Ethikos Debate Arena"
