from django.apps import AppConfig

class EthikosStatsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'ethikos.stats'
    verbose_name = "Ethikos Stats"
