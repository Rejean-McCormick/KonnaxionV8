from django.apps import AppConfig

class EthikosResolutionConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'ethikos.resolution'
    verbose_name = "Ethikos Resolution"
