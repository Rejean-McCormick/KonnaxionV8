from django.apps import AppConfig

class EthikosPrioritizationConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'ethikos.prioritization'
    verbose_name = "Ethikos Prioritization"
